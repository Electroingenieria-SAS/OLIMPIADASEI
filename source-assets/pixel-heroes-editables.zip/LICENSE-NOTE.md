Fuente de personajes suministrada por el titular del proyecto. Los archivos editables de esta carpeta no forman parte de GitHub Pages. La publicación de los atlas sí es necesaria para el videojuego.
