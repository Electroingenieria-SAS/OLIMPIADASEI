# ELECTROINGENIERÍA — PIXEL HEROES

**Paquete de seis personajes originales en pixel art, completamente animados y con fuentes editables.**

## 1. Qué incluye

| Perfil | Vestuario y elementos identificativos |
|:---|:---|
| **Jefe** | Traje azul marino ejecutivo, corbata dorada e insignia |
| **Coordinador** | Blazer corporativo azul, credencial y tableta |
| **Analista** | Camisa clara, gafas, acento azul y detalle de identificación |
| **Auxiliar** | Polo turquesa, pantalón oscuro y portapapeles |
| **Técnico** | Casco de seguridad amarillo, uniforme azul y cinturón de herramientas |
| **Operativo** | Casco blanco, chaleco de alta visibilidad, radio y botas |

Los seis mantienen proporciones, línea de contorno, sombras, escala y punto de anclaje compatibles entre sí. Los gráficos son **originales**, sin logos incrustados, para mantenerlos reutilizables en diferentes pantallas.

## 2. Animación y direcciones

Cada personaje cuenta con **32 cuadros por dirección × 4 direcciones = 128 cuadros**:

| Animación | Cuadros por dirección | Cuadros por personaje | Frecuencia sugerida |
|---|---:|---:|---:|
| Reposo / `idle` | 4 | 16 | 10 FPS |
| Caminar / `walk` | 8 | 32 | 10 FPS |
| Correr / `run` | 8 | 32 | 12 FPS |
| Interactuar / `interact` | 6 | 24 | 10 FPS |
| Celebrar / `celebrate` | 6 | 24 | 12 FPS |
| **TOTAL** | **32** | **128** | |

Direcciones para cada acción: `down` (hacia la cámara), `left` (izquierda), `right` (derecha), `up` (espalda).

**Gran total de 768 cuadros** distribuidos en 6 personajes.

## 3. Formatos de entrega

Dentro de `personajes/XX_rol/` se incluyen:

- `atlas_completo.png`: hoja de sprites completa de **512 × 1600 px**. Transparente y sin antialiasing.
- `spritesheets/idle.png`, `walk.png`, `run.png`, `interact.png`, `celebrate.png`: una hoja por acción, con **4 filas** en orden `down`, `left`, `right`, `up`.
- `frames/`: **128 PNG individuales** con nombres `accion_direccion_XX.png`.
- `animaciones.json`: coordenadas exactas, cuadro, acción, dirección y duración.
- `fuentes/XX_rol_animado.aseprite`: **fuente completa de la animación, con 128 fotogramas, 9 capas y 20 etiquetas de animación**. Se puede editar en Aseprite (ver observación técnica).
- `fuentes/XX_rol_capas.ora`: **9 capas del fotograma base**, editables con Krita y GIMP (formato OpenRaster).
- `fuentes/XX_rol_editable.svg`: **9 grupos vectoriales del fotograma base**, editables en Inkscape y software compatible con SVG.
- `fuentes/paleta_y_diseno.json`: colores y variables de indumentaria del personaje.

Otros archivos:

- `preview/catalogo_6_personajes.png`: catálogo ilustrado.
- `preview/XX_rol_walk.gif`: previsualización de caminata frontal.
- `preview/demo_interactiva.html`: **demo interactiva sin servidor ni conexión**, selección de los 6 personajes y desplazamiento en las cuatro direcciones.
- `herramientas/generar_assets.py`: código fuente reproducible en Python que genera los sprites, capas, atlas y metadatos.
- `docs/godot4_ejemplo.gd`: referencia de integración en Godot 4.
- `docs/phaser3_ejemplo.js`: referencia de integración en Phaser 3.

## 4. Cómo abrir la demo

Abra `preview/demo_interactiva.html` en Chrome, Firefox o Edge. Use las flechas o WASD para caminar, mantenga Shift para correr, barra espaciadora para interactuar y Z para celebrar. Puede cambiar de personaje, acción y dirección desde los botones. **No se necesita servidor.**

## 5. Edición recomendada

**Aseprite:** abra `fuentes/XX_rol_animado.aseprite`. La línea de tiempo está dividida en 20 etiquetas (`idle_down`, `walk_left`, etc.), con 9 capas por fotograma. Cambie traje, accesorios, cabello, color, posturas o secuencia sin perder las demás direcciones. Se recomienda guardar una copia antes de editar.

**Krita/GIMP:** abra `fuentes/XX_rol_capas.ora` para alterar por capas el diseño base de reposo frontal; para modificar la animación completa use el proyecto Aseprite o el generador.

**Inkscape:** abra `fuentes/XX_rol_editable.svg`. Cada capa es un `<g>` identificable; el arte está construido con rectángulos de píxel y puede editarse como vector.

**Configuración programática:** modifique la paleta del personaje en `herramientas/generar_assets.py` (`ROLES`); ejecute `python herramientas/generar_assets.py` desde cualquier directorio (requiere `pip install pillow`). Se reconstruyen los 768 cuadros y archivos derivados. Nota: los cambios hechos directamente a PNG o `.aseprite` se reemplazan si se vuelve a ejecutar el generador.

## 6. Integración en motor de juego

**Resolución original:** 64 × 80 píxeles por cuadro; colores RGBA con transparencia. **Atlas**: 8 columnas por 20 filas. La fila es:

```
fila = (indice_accion * 4) + indice_direccion
columna = indice_cuadro
rectangulo = (columna * 64, fila * 80, 64, 80)
```

Índices de acciones: `idle=0`, `walk=1`, `run=2`, `interact=3`, `celebrate=4`.
Índices de direcciones: `down=0`, `left=1`, `right=2`, `up=3`.

**Renderizado:** `NEAREST` / `pixelated` / `FilterMode.Point`, nunca suavizado bilineal; escalar a ×2, ×3 o ×4. Ancla recomendada: `x=0.5`, `y=0.94` (a nivel de pies). Para videojuegos con colisiones, use un rectángulo independiente del sprite centrado en los pies, aprox. **18 × 10 px**, que se ajuste al entorno real. **No use todo el tamaño de 64 × 80 como colisionador.**

## 7. Control de calidad y límites

- Las 6 siluetas y la paleta mantienen coherencia visual y rasgos individuales.
- Todos los cuadros se generan sobre cuadrículas de 64 × 80 px con fondo transparente y bordes nítidos.
- Incluye capas semánticas: sombra, piernas, brazo posterior, torso, cabeza, cabello/casco, brazo delantero, detalles y efectos.
- El formato `.aseprite` se escribe programáticamente siguiendo la estructura de archivos del formato Aseprite; se entrega además OpenRaster, SVG y PNG para compatibilidad.
- **Las animaciones se han generado y comprobado estructuralmente**, pero antes del lanzamiento definitivo se recomienda abrir el `.aseprite` en la versión concreta del editor y probarlo dentro del motor del juego para QA visual de cada secuencia y transiciones.
- No incluye colisiones de escenarios, sistema de misiones, rigging vectorial ni logos institucionales. Es un paquete **de personajes**, no un videojuego terminado.
