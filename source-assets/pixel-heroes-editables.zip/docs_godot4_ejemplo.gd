# Godot 4.x — plantilla para importar y animar cualquiera de los personajes.
# Estructura recomendada: nodo CharacterBody2D con hijo AnimatedSprite2D.
# Copia un 'atlas_completo.png' dentro de res://assets/ y ajusta atlas_path.
extends CharacterBody2D

@export_file("*.png") var atlas_path: String = "res://assets/01_jefe/atlas_completo.png"
@export var velocidad: float = 140.0
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

const W := 64
const H := 80
const DIRECTIONS := ["down", "left", "right", "up"]
const ACTIONS := ["idle", "walk", "run", "interact", "celebrate"]
const COUNTS := [4, 8, 8, 6, 6]
var facing: String = "down"

func _ready() -> void:
    var atlas: Texture2D = load(atlas_path)
    var collection := SpriteFrames.new()
    for a in range(ACTIONS.size()):
        for d in range(DIRECTIONS.size()):
            var animation: String = ACTIONS[a] + "_" + DIRECTIONS[d]
            collection.add_animation(animation)
            collection.set_animation_speed(animation, 12 if a in [2, 4] else 10)
            collection.set_animation_loop(animation, true)
            for f in range(COUNTS[a]):
                var tile := AtlasTexture.new()
                tile.atlas = atlas
                tile.region = Rect2(f * W, (a * 4 + d) * H, W, H)
                tile.filter_clip = true
                collection.add_frame(animation, tile)
    sprite.sprite_frames = collection
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    sprite.play("idle_down")

func _physics_process(_delta: float) -> void:
    var movement := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    velocity = movement * velocidad
    move_and_slide()
    if movement != Vector2.ZERO:
        if abs(movement.x) > abs(movement.y):
            facing = "right" if movement.x > 0.0 else "left"
        else:
            facing = "down" if movement.y > 0.0 else "up"
    var animation := ("walk" if movement != Vector2.ZERO else "idle") + "_" + facing
    if sprite.animation != animation:
        sprite.play(animation)
