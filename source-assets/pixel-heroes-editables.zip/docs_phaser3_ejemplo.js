/** Phaser 3: ejemplo de creación de secuencias a partir de atlas_completo.png.
 * Este snippet va dentro del método create() de tu Scene.
 * En preload() carga:
 * this.load.image('jefe-atlas', 'assets/01_jefe/atlas_completo.png');
 */
function prepararAnimaciones(scene, textureKey='jefe-atlas') {
  const acciones = [['idle',4,10],['walk',8,10],['run',8,12],['interact',6,10],['celebrate',6,12]];
  const direcciones = ['down','left','right','up'];
  acciones.forEach(([accion,cuadros,fps],ai)=>{
    direcciones.forEach((dir,di)=>{
      const key = `${textureKey}-${accion}_${dir}`;
      const frames=[];
      for(let i=0;i<cuadros;i++){
        const frameName=`${accion}_${dir}_${i}`;
        scene.textures.get(textureKey).add(frameName,0,i*64,(ai*4+di)*80,64,80);
        frames.push({key:textureKey,frame:frameName});
      }
      scene.anims.create({key,frames,frameRate:fps,repeat:-1});
    });
  });
}
// Después, en create():
// prepararAnimaciones(this,'jefe-atlas');
// const jugador = this.add.sprite(400,250,'jefe-atlas').setOrigin(.5,.94).setScale(3);
// jugador.play('jefe-atlas-walk_down');
